export class Owner {
    fname: string;
    lname: string;
    phoneprefix:  string;
    phone: string;
    email:string;
    identification:string;
    ownerFrom:Date;
    ownerTo:Date;
}
