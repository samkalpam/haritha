import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rent-a-flat',
  templateUrl: './rent-a-flat.component.html',
  styleUrls: ['./rent-a-flat.component.less']
})
export class RentAFlatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
